import static org.junit.Assert.assertArrayEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RemvConsecutiveDupTest
{
	private RemvConsecutiveDup r;
	
	@Before
	public void init()
	{
		System.out.println("Test Started");
		r=new RemvConsecutiveDup();
	}
	
	@After
	public void afterTest()
	{
		System.out.println("Test Finished");
	}
	
	@Test
	public void removeDuplicateTest1()
	{
		int[] arr = new int[] { 1, 1, 2, 2, 2, 1, 1, 1 };
		int[] resultArr = r.removeDup(arr);		
		assertArrayEquals(new int[] {1, 2, 1,0,0,0,0,0},  resultArr);
	}
	@Test
	public void removeDuplicateTest2()
	{
		int[] arr = new int[] { 1, 1, 1, 1 };
		int[] resultArr = r.removeDup(arr);		
		assertArrayEquals(new int[] {1, 0, 0, 0},  resultArr);
	}
	
	@Test
	public void removeDuplicateTest3()
	{
		int[] arr = new int[0];
		int[] resultArr = r.removeDup(arr);		
		assertArrayEquals(new int[0],  resultArr);
	}
	
	@Test
	public void removeDuplicateTest4()
	{
		int[] arr = new int[]{1,2,3,4};
		int[] resultArr = r.removeDup(arr);		
		assertArrayEquals(new int[]{1,2,3,4},  resultArr);
	}
	
	
}
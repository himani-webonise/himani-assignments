import java.util.Arrays;


public class RemvConsecutiveDup
{

	public int[] removeDup(int[] arr)
	{	

		int len=arr.length;
		
		len--;
		int length=len-1;
		System.out.println("length "+len);
		for(int i=0;i<length;)
		{
			System.out.println("outer:: ");
			System.out.println("i:"+i);
			if(arr[i]==arr[i+1])
			{
				for(int j=i;j<(length);j++)
				{
					System.out.println("j:"+j);
					arr[j]=arr[j+1];
					
					System.out.println("element"+arr[j]);
				}
				arr[len]=0;
				len--;
				length=len;
			}
			
			else
				i++;
			
			System.out.println("----------");
		}

		return arr;
	}
}